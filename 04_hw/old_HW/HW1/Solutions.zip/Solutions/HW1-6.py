# -*- coding: utf-8 -*-
"""
ISE224: HW1-6

@author: cxc1920
"""

age = int(input("Your age: "))

print(f"You are {age} years old.")
