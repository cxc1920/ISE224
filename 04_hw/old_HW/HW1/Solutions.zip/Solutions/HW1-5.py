# -*- coding: utf-8 -*-
"""
ISE224: HW1-5

@author: cxc1920
"""

first_num = int(input("Your first number: "))
second_num = int(input("Your second number: "))

sum = first_num + second_num

print(sum)

