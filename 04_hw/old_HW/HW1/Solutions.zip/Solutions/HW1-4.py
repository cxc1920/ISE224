# -*- coding: utf-8 -*-
"""
Created on Mon Jan 30 18:51:59 2023

@author: cxc1920
"""

input1 = input("Your first input: ")
input2 = input("Your second input: ")
input3 = input("Your third input: ")

print(input1,input2,input3,sep="@_@", end="^_^")
