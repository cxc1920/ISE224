# -*- coding: utf-8 -*-
"""
ISE224: HW1-1

@author: cxc1920
"""

name = "Yujie"
major = "Industrial Engineering"
food = "Orange chicken"

print(name)
print(major)
print(food)
