# -*- coding: utf-8 -*-
"""
ISE224: HW1-2

@author: cxc1920
"""

name = input("What is your name? ")
major = input("What is your major? ")
food = input("What is your favorite food? ")

print(name)
print(major)
print(food)
