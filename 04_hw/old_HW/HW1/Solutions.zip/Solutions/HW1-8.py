# -*- coding: utf-8 -*-
"""
ISE224: HW1-8

@author: cxc1920
"""

celsius = float(input("Celsius: "))

fahrenheit = 9/5 * celsius + 32

print(f"Fahrenheit: {fahrenheit:.1f}")

