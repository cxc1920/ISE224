# -*- coding: utf-8 -*-
"""
ISE224: HW1-9

@author: cxc1920
"""

pi = 3.14159

radius = float(input("Enter the radius of the circle: "))

perimeter = 2 * pi * radius
area = pi * radius**2

print(f"Perimeter: {perimeter:>10.4f}")
print(f"Area: {area:>10.4f}")


