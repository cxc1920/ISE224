# -*- coding: utf-8 -*-
"""
ISE224: HW1-3

@author: cxc1920
"""

name = input("Enter your name: ")
major = input("Enter your major: ")
food = input("Enter your favorite food: ")

sentence = "I'm " + name + ". My major is " + major + ". My favorite food is " + food + "!"

print(sentence)
